const telegramBot = require("node-telegram-bot-api");
const fs = require("fs");
const yauzl = require('yauzl');
const mkdirp = require('mkdirp');
const archiver = require("archiver");
const axios = require("axios");
const path = require("path");

process.on('uncaughtException', (error) => {
    console.error('Uncaught Exception:', error);
});
    
process.on('unhandledRejection', (reason, promise) => {
    console.error('Unhandled Rejection at:', promise);
    console.error('Reason:', reason);
});

const cloudflare = require(__dirname + "/cloudflare.js");

var settings = JSON.parse(fs.readFileSync(__dirname + "/settings.json"));

setInterval(() => {
    settings = JSON.parse(fs.readFileSync(__dirname + "/settings.json"));
}, 10000);

var pointers = JSON.parse(fs.readFileSync(__dirname + "/pointers.json"));

setInterval(() => {
    pointers = JSON.parse(fs.readFileSync(__dirname + "/pointers.json"));
}, 10000);

const bot = new telegramBot(settings.botToken, {
    polling: true
});

function isValidDomain(domain) {
    const validDomainPattern = new RegExp('^(?!-)[a-zA-Z0-9-]{1,63}(?<!-)$');
    const validIpPattern = new RegExp('^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$');

    if (validIpPattern.test(domain)) {
        return true;
    }

    const parts = domain.split('.');

    if (parts.length !== 2) {
        return false;
    }

    for (let part of parts) {
        if (!validDomainPattern.test(part)) {
            return false;
        }
    }

    return true;
}

const forceRemoveDirectory = (directoryPath) => {
    if (!fs.existsSync(directoryPath)) {
        return;
    }

    const files = fs.readdirSync(directoryPath);

    files.forEach((file) => {
        const filePath = path.join(directoryPath, file);
        if (fs.statSync(filePath).isDirectory()) {
            forceRemoveDirectory(filePath);
        } else {
            fs.unlinkSync(filePath);
        }
    });

    fs.rmdirSync(directoryPath);
};

function extractZip(zipFilePath, outputDir) {
    return new Promise((resolve, reject) => {
        yauzl.open(zipFilePath, {
            lazyEntries: true
        }, (err, zipfile) => {
            if (err) {
                reject(err);
                return;
            }

            if (!fs.existsSync(outputDir)) {
                fs.mkdirSync(outputDir, {
                    recursive: true
                });
            }

            zipfile.readEntry();
            zipfile.on('entry', (entry) => {
                if (/\/$/.test(entry.fileName)) {
                    const dirPath = path.join(outputDir, entry.fileName);
                    mkdirp.sync(dirPath);
                    zipfile.readEntry();
                } else {
                    zipfile.openReadStream(entry, (err, readStream) => {
                        if (err) {
                            console.error(`Error extracting ${entry.fileName}:`, err);
                            zipfile.readEntry(); 
                            return;
                        }

                        const filePath = path.join(outputDir, entry.fileName);
                        const fileDir = path.dirname(filePath);

                        mkdirp.sync(fileDir); 
                        readStream.pipe(fs.createWriteStream(filePath));
                        readStream.on('end', () => zipfile.readEntry());
                        readStream.on('error', (err) => {
                            console.error(`Error writing ${entry.fileName}:`, err);
                            zipfile.readEntry(); 
                        });
                    });
                }
            });

            zipfile.on('end', () => {
                resolve();
            });

            zipfile.on('error', (err) => {
                reject(err);
            });
        });
    });
}

var onReplies = {};
var pendingWork = {};

bot.on("callback_query", async (callback) => {
    try {
        const user = callback.from.id.toString();
        const commandName = callback.data;

        if (commandName.startsWith("updatedns_")) {
            const chatId = user;
            const domain = commandName.split("updatedns_")[1];
            try {
                await bot.deleteMessage(user, callback.message.message_id).catch(E => {})
            } catch (E) {}
            if (pendingWork[domain] != null) {
                if (pointers[domain]) {
                    try {
                        delete pendingWork[domain];
                    } catch (E) {}
                    return bot.sendMessage(chatId, "This site is already registered, to delete it please do <code>/delete</code>!", {
                        parse_mode: "HTML"
                    })
                };
                const addedDomain = await cloudflare.addDomain(domain, pendingWork[domain].cloudflare.apiKey, pendingWork[domain].cloudflare.accountId);
                if (addedDomain) {
                    const {
                        downloadUrl,
                        pointer
                    } = pendingWork[domain];
                    const waitingIcon = await bot.sendMessage(chatId, `⌛`);
                    const downloadingMessage = await bot.sendMessage(chatId, `<code>Please wait while we download your web-files.</code>`, {
                        "parse_mode": "HTML"
                    });
                    const response = await axios({
                        url: downloadUrl,
                        method: 'GET',
                        responseType: 'stream',
                    });
                    response.data.pipe(fs.createWriteStream(__dirname + "/sites/" + pointer + ".zip"));
                    response.data.on('end', async () => {
                        setTimeout(async () => {
                            const outputDir = __dirname + "/sites/" + pointer;
                            extractZip(__dirname + "/sites/" + pointer + ".zip", outputDir).then(async Response => {
                                try {
                                    fs.unlinkSync(__dirname + "/sites/" + pointer + ".zip");
                                } catch (E) {}
                                const pointersJSON = JSON.parse(fs.readFileSync(__dirname + "/pointers.json"));
                                pointersJSON[domain] = pointer;
                                fs.writeFileSync(__dirname + "/pointers.json", JSON.stringify(pointersJSON));
                                return bot.sendMessage(chatId, `✅ Your webfiles have been successfully downloaded and so <b>your site has been setup: https://${domain}/</b>\n\nThe SSL may be processing which can take up to 48 hours, but usually takes 5-20 minutes. If it still continues to not work after 3 hours contact @riddancedev on telegram - if you made a mistake or if the service simply isn't working our support can assist you.\n\nIf you need any further assistance (site not loading or extra-addons not working), please contact @riddancedev on telegram.`, {
                                    "parse_mode": "HTML"
                                });
                            }).catch(async E => {
                                try {
                                    fs.unlinkSync(__dirname + "/sites/" + pointer + ".zip")
                                } catch (E) {}
                                return bot.sendMessage(chatId, `❌ Sorry something went wrong and your file failed to be downloaded to our server.`);
                            })
                        })
                    });
                    response.data.on('error', async (err) => {
                        try {
                            fs.unlinkSync(__dirname + "/sites/" + pointer + ".zip")
                        } catch (E) {}
                        return bot.sendMessage(chatId, `❌ Sorry something went wrong and your file failed to be downloaded to our server.`);
                    });
                } else {
                    try {
                        delete pendingWork[domain];
                    } catch (E) {}
                    return bot.sendMessage(chatId, "This domain is not allowed on the cloudflare network. ☁ ⛔ This is usually because it contains a key-word that is blacklisted or it is an unsupported TTL.", {
                        "parse_mode": "HTML"
                    });
                }
            }
        }
    } catch (E) {
        console.log(E);
    }
})

bot.on("message", async (msg) => {
    const user = msg.from.id;
    const chatId = msg.chat.id;

    if (onReplies[user] != null) {
        onReplies[user](msg);
        try {
            delete onReplies[user];
        } catch (E) {}
        return true;
    };

    if (msg.text != null) {
        if (msg.text.toLowerCase().split(" ")[0] == "/id") {
            return bot.sendMessage(chatId, `Your user id is <code>${user}</code>.`, {
                "parse_mode": "HTML"
            });
        };
    } else {
        return false;
    };

    if (settings.access.includes(user.toString())) { // admin commands
        if (msg.text.toLowerCase().split(" ")[0] == "/delete") {
            if (msg.text.split(" ")[1] != null) {
                const pointersJSON = JSON.parse(fs.readFileSync(__dirname + "/pointers.json"));
                if (pointersJSON[msg.text.split(" ")[1]]) {
                    const pointer = pointersJSON[msg.text.split(" ")[1]];
                    delete pointersJSON[msg.text.split(" ")[1]];
                    fs.writeFileSync(__dirname + "/pointers.json", JSON.stringify(pointersJSON))
                    try {
                        forceRemoveDirectory(__dirname + "/sites/" + pointer);
                    } catch(E) {}
                    try {
                        fs.unlinkSync(__dirname + "/sites/" + pointer + ".zip");
                    } catch(E) {}
                    return bot.sendMessage(chatId, "This domain has been deleted!", {
                        parse_mode: "HTML"
                    })
                } else {
                    return bot.sendMessage(chatId, "This domain is not registered!", {
                        parse_mode: "HTML"
                    })
                }
            } else {
                return bot.sendMessage(chatId, "You must mention a domain, for example: <code>/delete google.com</code>", {
                    parse_mode: "HTML"
                })
            }
        }
        
        if (msg.text.toLowerCase().split(" ")[0] == "/upload") {
            await bot.sendMessage(chatId, `▶ Please now attach a <code>.ZIP</code> file containing your web-contents.`, {
                parse_mode: "HTML"
            });
            let replied = false;
            onReplies[user] = async function (message) {
                if (!replied) {
                    replied = true;
                    try {
                        delete onReplies[user];
                    } catch (E) {}
                    if (message.document != null && message.document.mime_type == "application/zip") {

                        const fileUrl = await bot.getFileLink(message.document.file_id);
                        const pointerId = String(new Date().getTime() + "_" + Math.random());

                        bot.sendMessage(chatId, "⏭ <b>Please purchase a domain from your choice of provider.</b>\n<code>We recommend NJALLA (https://njal.la) as they accept cryptocurrency and respect privacy.</code>\n\n⚠ Do not include 'https' or 'http' or any paths or subdomains (e.g if your domain was <code>https://www.google.com/</code> you'd only enter <code>google.com</code> ⚠)\n\nAfter purchasing a domain please enter the domain you purchased in the chat, if you already purchased a domain please enter it now.", {
                            parse_mode: "HTML"
                        }).then(R => {
                            let replied = false;
                            onReplies[user] = function (message) {
                                if (!replied) {
                                    replied = true;
                                    try {
                                        delete onReplies[user];
                                    } catch (E) {}
                                    const urlEntered = message.text;
                                    if (isValidDomain(urlEntered) != false) {
                                        const mainUrl = urlEntered;
                                        if (pointers[mainUrl]) {
                                            return bot.sendMessage(chatId, "This site is already registered, to delete it please do <code>/delete</code>!", {
                                                parse_mode: "HTML"
                                            })
                                        };
                                        pendingWork[mainUrl] = {
                                            "domain": mainUrl,
                                            "pointer": pointerId,
                                            "cloudflare": settings.cloudflare,
                                            "downloadUrl": fileUrl
                                        }
                                        return bot.sendMessage(chatId, `☁ <b>Please update the nameservers of your domain [${mainUrl}] to the following:</b>\n\n1. <code>${settings.cloudflare.nameservers.split("\n")[0]}</code>\n2. <code>${settings.cloudflare.nameservers.split("\n")[1]}</code>\n\n➡️ Once you have updated the nameservers, please press the Next button below.`, {
                                            "parse_mode": "HTML",
                                            reply_markup: {
                                                inline_keyboard: [
                                                    [{
                                                        text: "Next - I updated nameservers!",
                                                        callback_data: "updatedns_" + mainUrl
                                                    }]
                                                ]
                                            },
                                        });
                                    }
                                }
                            }
                        });
                    }
                }
            };
        };
    }
});

module.exports = function () {
    console.log("Bot script running!")
}