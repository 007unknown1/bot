const request = require("request");
const fs = require("fs");

var settings = JSON.parse(fs.readFileSync(__dirname + "/settings.json"));

setInterval(() => {
    settings = JSON.parse(fs.readFileSync(__dirname + "/settings.json"));
}, 10000);

function addDomain(domain, api, accountId) {
    return new Promise((resolve, reject) => {
        request("https://api.cloudflare.com/client/v4/zones", {
            "headers": {
                "content-type": "application/json",
                "Authorization": "Bearer " + api
            },
            "body": "{\"name\":\"" + domain + "\",\"account\":{\"id\":\"" + accountId + "\"},\"jump_start\":false}",
            "method": "POST"
        }, async (err, resp) => {
            if (!err) {
                try {
                    var data = JSON.parse(resp.body);
                    if (data.success) {
                        if (data.result != null) {
                            data = data.result;
                            var id = data.id.toString();
                            resolve(true);
                            request("https://api.cloudflare.com/client/v4/zones/" + id + "/dns_records", {
                                "headers": {
                                    "content-type": "application/json",
                                    "Authorization": "Bearer " + api
                                },
                                "method": "POST",
                                "body": "{\"content\":\"" + settings.serverIp + "\",\"data\":{},\"name\":\"" + domain + "\",\"proxiable\":true,\"proxied\":true,\"ttl\":1,\"type\":\"A\",\"zone_id\":\"" + id + "\",\"zone_name\":\"" + domain + "\",\"comment\":null,\"tags\":[]}",
                            }, async (err) => {});
                            request("https://api.cloudflare.com/client/v4/zones/" + id + "/settings/always_use_https", {
                                "headers": {
                                    "content-type": "application/json",
                                    "Authorization": "Bearer " + api
                                },
                                "method": "PATCH",
                                "body": "{\"value\":\"on\"}",
                            }, async (err) => {});
                        } else {
                            resolve(false);
                        }
                    } else {
                        if (data.errors[0].code == 1061) { // already exists
                            resolve(true);
                        } else {
                            resolve(false);
                        }
                    }
                } catch(e) {
                    resolve(false);
                }
            } else {
                resolve(false);
            }
        });
    })
}

module.exports = {
    "addDomain": addDomain
}