const fs = require("fs");
const mime = require("mime");
const path = require("path");
const express = require("express");

process.on('uncaughtException', (error) => {
    console.error('Uncaught Exception:', error);
});
    
process.on('unhandledRejection', (reason, promise) => {
    console.error('Unhandled Rejection at:', promise);
    console.error('Reason:', reason);
});

const app = new express();

var pointers = JSON.parse(fs.readFileSync(__dirname + "/pointers.json"));

setInterval(() => {
    pointers = JSON.parse(fs.readFileSync(__dirname + "/pointers.json"));
}, 10000);

function serveFile(filePath, res) {
    const fileStream = fs.createReadStream(filePath);
    const contentType = mime.lookup(path.extname(filePath)) || "application/octet-stream";
    res.setHeader("Content-Type", contentType);
    return fileStream.pipe(res);
}

app.use("*", (req, res, next) => {
    const domain = req.hostname;
    const file_path = req.baseUrl;
    if (pointers[domain]) {
        const requestedFile = __dirname + "/sites/" + pointers[domain] + file_path;
        const isDirectory = fs.statSync(requestedFile).isDirectory();
        if (isDirectory) {
            const indexPath = path.join(requestedFile, "index.html");
            fs.access(indexPath, fs.constants.F_OK, (err) => {
                if (err) {
                    return res.status(404).send("Not found.");
                } else {
                    return serveFile(indexPath, res);
                }
            });
        } else {
            fs.access(requestedFile, fs.constants.F_OK, (err) => {
                if (err) {
                    return res.status(404).send("Not found.");
                } else {
                    return serveFile(requestedFile, res);
                }
            });
        }
    } else {
        return res.status(404).send("Not found.");
    }
});

app.listen(80, () => {
    console.log("Website listening on port 80!")
    require(__dirname + "/bot.js")();
});